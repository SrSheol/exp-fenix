import pymupdf as fz, sys, subprocess
a=fz.open('/mnt/user-data/uploads/EXP__SERVICIO_LOMAS_ESTRELLA__S_A__DE_C_V_.pdf'); b=fz.open(sys.argv[1])
pages=[int(x) for x in sys.argv[2].split(',')]; dpi=int(sys.argv[3]) if len(sys.argv)>3 else 60
clip=None
if len(sys.argv)>4 and sys.argv[4]: clip=fz.Rect(*[float(v) for v in sys.argv[4].split(',')])
fs=[]
for p in pages:
    for tag,d in (('o',a),('n',b)):
        fn=f'/tmp/r/s_{tag}{p}.png'; d[p-1].get_pixmap(dpi=dpi,clip=clip).save(fn); fs.append(fn)
subprocess.run(['montage',*fs,'-tile','2x','-geometry','+4+4','-background','#999',sys.argv[5] if len(sys.argv)>5 else '/tmp/r/sbs.png'])
