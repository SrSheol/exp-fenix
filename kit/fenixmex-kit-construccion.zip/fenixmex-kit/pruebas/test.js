const fs=require('fs');
globalThis.PDFLib=require('pdf-lib'); globalThis.fontkit=require('@pdf-lib/fontkit');
require('./engine.js');
const rd=p=>new Uint8Array(fs.readFileSync(p));
const fonts={}; for(const k of ['R','B','I','N','NB','S','SB','SI','SBI','DJ','DJB','RND']) fonts[k]=rd('/tmp/fonts/sub/'+k+'.ttf');
const A={tplExp:rd('/tmp/b/tpl_exp.pdf'),tplPrevio:rd('/tmp/b/tpl_previo.pdf'),tplDict:rd('/tmp/b/tpl_dict.pdf'),fonts,
 map:{exp:JSON.parse(fs.readFileSync('/tmp/b/map_exp.json')),cat2:JSON.parse(fs.readFileSync('/tmp/b/map_cat2.json'))},
 globals:{firmanteIzquierdoFirma:rd('fx/fi.png'),firmaPnd1:rd('fx/pnd1.png'),firmaPnd2:rd('fx/pnd2.png'),logoFenix:process.env.LOGO?rd(process.env.LOGO):null}};
(async()=>{
 const st=JSON.parse(fs.readFileSync(process.argv[2]||'fx/state.json'));
 st.testigo1Firma=rd('fx/t1.png'); st.testigo2Firma=rd('fx/t2.png'); st.representanteLegalFirma=rd('fx/rep.png');
 const t=Date.now();
 const r=await FXEngine.buildExpediente(st,A);
 fs.writeFileSync(process.argv[3]||'out_exp.pdf',r.bytes); console.log('pages',r.pages,'ms',Date.now()-t,'bytes',r.bytes.length);
 let i=0; for(const e of st.equipos){ i++; if(FXEngine.equipoCtx(e,i).cat==='II'){ for(const k of ['previo','dictamen']){ const b=await FXEngine.buildCat2(k,st,e,i,A); fs.writeFileSync(`out_${k}_${e.tag}.pdf`,b);} console.log('cat2',e.tag);} }
})().catch(e=>{console.error(e);process.exit(1)});
