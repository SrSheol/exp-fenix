import asyncio, os
from playwright.async_api import async_playwright
os.environ['PLAYWRIGHT_BROWSERS_PATH']='/opt/pw-browsers'
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        ctx=await b.new_context(viewport={'width':1360,'height':900},accept_downloads=True)
        pg=await ctx.new_page()
        errs=[]
        pg.on('console',lambda m: errs.append(m.text) if m.type in('error','warning') else None)
        pg.on('pageerror',lambda e: errs.append('PAGEERROR '+str(e)))
        pg.on('dialog',lambda d: asyncio.ensure_future(d.accept()))
        await pg.goto('file:///tmp/n/index.html'); await pg.wait_for_timeout(1500)
        await pg.screenshot(path='/tmp/r/ui1.png',full_page=False)
        await pg.click('#btnEjemplo'); await pg.wait_for_timeout(500)
        for key,f in [('g_firmaPnd1','fx/pnd1.png'),('g_firmaPnd2','fx/pnd2.png'),('g_firmanteIzquierdoFirma','fx/fi.png'),('d_representanteLegalFirma','fx/rep.png'),('d_testigo1Firma','fx/t1.png'),('d_testigo2Firma','fx/t2.png')]:
            await pg.set_input_files('#f_'+key,f); await pg.wait_for_timeout(250)
        # agregar equipo Cat II
        await pg.click('#btnAgregar'); await pg.wait_for_timeout(300)
        card=pg.locator('.equipo').nth(1)
        vals={'numeroSerie':'A-77','presionOperacion':'6','presionCalibracion':'7.5','presionDiseno':'10','presionTrabajoMaxPermitida':'12','presionPruebaHidrostatica':'13','capacidadVolumetrica':'0.024','marca':'CAMPBELL','codigoMemoriaCalculo':'RSP-020-040-2026','folio':'051'}
        for k,v in vals.items(): await card.locator(f'[data-k="{k}"]').fill(v)
        await card.locator('[data-k="fechaPnd"]').fill('2026-03-04')
        for c in ['espEnv','espSup','espInf']:
            for r in range(16): await card.locator(f'[data-esp="{c}"][data-r="{r}"]').fill('3.2')
        await pg.fill('#d_dom','CARRETERA FEDERAL KM 12, TEXCOCO, ESTADO DE MÉXICO')
        await pg.wait_for_timeout(600)
        await pg.screenshot(path='/tmp/r/ui2.png',full_page=False)
        await pg.locator('#s-equipos').scroll_into_view_if_needed(); await pg.screenshot(path='/tmp/r/ui3.png')
        print('validacion:',(await pg.inner_text('#validacion'))[:600])
        async with pg.expect_download(timeout=120000) as dl:
            await pg.click('#btnZip')
        d=await dl.value; await d.save_as('/tmp/n/ui_out.zip'); print('zip',d.suggested_filename)
        await pg.locator('#s-generar').scroll_into_view_if_needed(); await pg.screenshot(path='/tmp/r/ui4.png')
        # recarga: persistencia
        await pg.reload(); await pg.wait_for_timeout(1500)
        print('persist rs:',await pg.input_value('#d_rsu'),'| equipos:',await pg.locator('.equipo').count(),'| firma t1 thumb:', await pg.locator('[data-img="d:testigo1Firma"] .thumb').get_attribute('style'))
        print('ERRS',errs)
        await b.close()
asyncio.run(main())
