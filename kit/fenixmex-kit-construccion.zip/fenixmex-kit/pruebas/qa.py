import pymupdf as fz, numpy as np, sys
a=fz.open('/mnt/user-data/uploads/EXP__SERVICIO_LOMAS_ESTRELLA__S_A__DE_C_V_.pdf'); b=fz.open(sys.argv[1])
print('pages',len(a),len(b))
res=[]
for i in range(min(len(a),len(b))):
    if a[i].rect!=b[i].rect: print('SIZE DIFF',i+1,a[i].rect,b[i].rect)
    pa=a[i].get_pixmap(dpi=40,colorspace=fz.csGRAY); pb=b[i].get_pixmap(dpi=40,colorspace=fz.csGRAY)
    if (pa.w,pa.h)!=(pb.w,pb.h): print('dim',i+1); continue
    A=np.frombuffer(pa.samples,np.uint8).astype(int); B=np.frombuffer(pb.samples,np.uint8).astype(int)
    res.append((round(float((np.abs(A-B)>64).mean()*100),3),i+1))
res.sort(reverse=True); print(res[:30])
