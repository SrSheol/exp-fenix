# FenixMex — Generador de expedientes NOM-020-STPS-2011

## Uso diario
Abre `fenixmex-expedientes-nom020.html` en Chrome, Edge o Firefox (doble clic o alojado en GitHub Pages).
Funciona sin internet: plantillas, fuentes y librerías (pdf-lib, fontkit, JSZip) van dentro del archivo.
Los datos y las imágenes se guardan en IndexedDB del navegador. Usa "Exportar borrador" para respaldos.

## Cómo funciona
Las plantillas son los PDF de ejemplo "limpios": se retiraron solo los textos variables, las firmas y las fotos.
El resto (tablas, logos, textos fijos, tamaños de página) es el original sin tocar.
`build/map_exp.json` guarda la posición exacta (espacio de usuario PDF) de cada campo; el motor (`app/engine.js`) clona páginas, escribe los datos y firmas, pinta franjas (hojas 44/68) y desplaza la hoja 108 al día de la semana del PND.

## Regenerar plantillas (solo si cambia el PDF de ejemplo)
Requisitos: Python 3 con pymupdf, pikepdf, pdfplumber, fonttools; Node con pdf-lib@1.17.1, @pdf-lib/fontkit@1.1.1, jszip@3.10.1.
Las rutas de trabajo están fijas en los scripts (`/tmp/b`, `/tmp/n`, `/tmp/fonts/sub`); ajústalas a tu equipo.
1. En `build/`: `python3 clean.py && python3 stage2.py && python3 build_map.py && python3 spec_cat2.py`
2. `python3 qa_diff.py` no debe imprimir nada (sin daños fuera de los campos).
3. `python3 app/assemble.py` produce el HTML único.
4. Prueba: `node pruebas/test.js pruebas/state.json salida.pdf` y `python3 pruebas/qa.py salida.pdf`.

## Decisiones fijadas
- Hojas por equipo: 8–18, 20 (plano y memoria), 23 (programa de calibración), 44, 46, 48, 62, 64, 68, 70–75, 102, 106, 107, 108. La hoja 66 solo para categoría III.
- Las hojas 3 (relación) y 6 (listado) crecen por renglones: 20 y 16 equipos por hoja.
- Número de control STPS siempre vacío; previo con FOLIO xxx y firmante XXX; fechas derivadas de la Fecha PND.
- Fuentes sustitutas para textos variables:

| Fuente original | Sustituta |
|---|---|
| Arial / Arial Nova | Liberation Sans |
| Arial Narrow | Liberation Sans Narrow |
| Times / Minion / Cambria | Liberation Serif |
| Lucida Sans | DejaVu Sans |
| Arial Rounded MT Bold | Nunito ExtraBold |

- Se respeta la itálica simulada del original.
