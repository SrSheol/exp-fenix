import base64, json, re
rd=lambda p: open(p,'rb').read()
b=lambda p: base64.b64encode(rd(p)).decode()
fonts={k:b(f'/tmp/fonts/sub/{k}.ttf') for k in ['R','B','I','N','NB','S','SB','SI','SBI','DJ','DJB','RND']}
assets=dict(tplExp=b('/tmp/b/tpl_exp.pdf'),tplPrevio=b('/tmp/b/tpl_previo.pdf'),tplDict=b('/tmp/b/tpl_dict.pdf'),fonts=fonts,
  map=dict(exp=json.load(open('/tmp/b/map_exp.json')),cat2=json.load(open('/tmp/b/map_cat2.json'))))
def safe(js): return js.replace('</script','<\\/script')
h=open('app.html').read()
parts={'/*LIB_PDFLIB*/':rd('node_modules/pdf-lib/dist/pdf-lib.min.js').decode(),
 '/*LIB_FONTKIT*/':rd('node_modules/@pdf-lib/fontkit/dist/fontkit.umd.min.js').decode(),
 '/*LIB_JSZIP*/':rd('node_modules/jszip/dist/jszip.min.js').decode(),
 '/*ENGINE*/':open('engine.js').read(),
 '/*ASSETS*/':'window.FX_ASSETS='+json.dumps(assets,ensure_ascii=False,separators=(',',':'))+';'}
for k,v in parts.items():
    assert h.count(k)==1,k
    h=h.replace(k,safe(v))
open('/tmp/n/index.html','w').write(h)
import os; print(os.path.getsize('/tmp/n/index.html')/1e6,'MB')
